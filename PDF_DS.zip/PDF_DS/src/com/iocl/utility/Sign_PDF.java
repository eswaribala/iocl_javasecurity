package com.iocl.utility;

import com.java4less.pdf.signature.PDFSignatureFacade;

public class Sign_PDF {
	public static void main(String[] args){
        
		PDFSignatureFacade facade = new PDFSignatureFacade();
		facade.sign("certs/j4l_test.p12","test","resources/security-spec.pdf","resources/signedspec.pdf");
	  }
}
