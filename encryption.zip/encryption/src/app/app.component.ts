import { Component } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import {LoginService} from "./services/login.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EncryptionDecryptionSample';

  userName:string;
  plainText:string;
  encryptText: string;
  encPassword: string;
  decPassword:string;
  conversionEncryptOutput: string;
  conversionDecryptOutput:string;

  constructor(private loginService:LoginService ) {
  }
  //method is used to encrypt and decrypt the text
  convertText(conversion:string) {
      if (conversion=="encrypt") {
        this.conversionEncryptOutput = CryptoJS.AES.encrypt(this.plainText.trim(), this.encPassword.trim()).toString();
        let obj={
        "userName": this.userName,
          "password":this.conversionEncryptOutput,
          "enabled":1
        }
        this.loginService.validateUser(obj).subscribe(response=>{
          console.log(response);
        })

      }
      else {
        this.conversionDecryptOutput = CryptoJS.AES.decrypt(this.encryptText.trim(), this.decPassword.trim()).toString(CryptoJS.enc.Utf8);

    }
  }
}
