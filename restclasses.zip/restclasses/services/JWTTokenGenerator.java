package com.iocl.services;


import java.util.Date;
import java.util.Random;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONException;

import com.iocl.models.LoginResponse;
import com.iocl.models.Message;
import com.iocl.models.Trader;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import io.jsonwebtoken.*;
import java.util.Date;    
 

@Path("/JWTAPI")
public class JWTTokenGenerator {
    @GET
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Response GetTrader()
	{
		Message message = new Message();
		message.setMessageId(new Random().nextInt(10000));
		message.setInfo("will generate data");
		GenericEntity<Message> genentity = 
				new GenericEntity<Message>(message) {};
		
		
		return Response
				 .status(200)
		            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(genentity)
		            .build();
		          
		    
	}
    
    @POST
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response GetData(Trader trader ) throws JSONException
	{
		String email=trader.getEmail();
		System.out.println(email);
		LoginResponse loginResponse=null;
		
		if(email.equals("admin@rps.com"))
		{
			
		  //Let's set the JWT Claims
		loginResponse =new LoginResponse( Jwts.builder().setSubject(trader.getEmail())
	            .claim("roles", "admin").setIssuedAt(new Date())
	            .signWith(SignatureAlgorithm.HS256, "secretkey").compact());
		}
		
		System.out.println(loginResponse.token);
		GenericEntity<LoginResponse> genentity = 
				new GenericEntity<LoginResponse>(loginResponse) {};
		 
		return Response
				 .status(200)
		            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(genentity)
		            .build();
		          
		
	}
}
