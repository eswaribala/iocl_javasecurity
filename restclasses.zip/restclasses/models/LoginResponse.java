package com.iocl.models;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LoginResponse {
	public String token;
	public LoginResponse()
	{
		
	}
    public LoginResponse(final String token) {
        this.token = token;
    }
}
